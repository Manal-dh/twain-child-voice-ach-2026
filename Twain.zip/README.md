# Narrative Texts for the Twain Child-Voice Study

Archive created (UTC): 2026-10-31T17:03:20.508132+00:00

## Contents

- Twain: 3 works; 248,254 word tokens.
- Child: 8 works; 561,064 word tokens.
- Adult: 28 works; 2,636,433 word tokens.

These are cleaned research texts derived from Project Gutenberg sources.
The archive contains 39 narrative-only text files.

## Preparation

Source identities, work completeness, and narrative boundaries were checked.
Front matter, contents pages, structural headings, illustration captions,
identified explanatory notes, epigraphs, Gutenberg notices, and licenses
were excluded from the analysis texts. Concluding narrative prose was retained.
Original source files were preserved separately.

The two volumes of each James novel were joined in narrative order.
Works embedded in larger collections were extracted separately.

Little Women includes both parts.
Old Creole Days contains eight stories from the supplied edition.
Main-Travelled Roads contains eleven stories from the supplied expanded edition.
The Scarlet Letter excludes The Custom-House introduction.
Moby-Dick excludes Etymology and Extracts, but retains the epilogue narrative.

## Token rule

Lowercase text and convert right curly apostrophes to straight apostrophes.
Extract tokens with: [a-z]+(?:['-][a-z]+)*

Retain single-letter words, contractions, and internally hyphenated words.
Do not remove stopwords, stem, lemmatize, or correct vernacular spelling.

## Manifest

manifest.csv records each file's corpus, concatenation order, token count,
type count, byte size, and SHA-256 hash.

The archive creation date is not the original download date.
The manifest describes the cleaned files, not historical source downloads.

## Accompanying documentation

Share this archive with the analysis notebooks and the paper's source and
edition inventory, including Gutenberg ebook IDs and available acquisition
records. Original Gutenberg source notices and terms are not reproduced
inside the cleaned analysis texts.
